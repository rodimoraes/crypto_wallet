class Pessoa
    def falar
       "Olá, pessoal!"  
    end
end