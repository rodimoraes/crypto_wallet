# Ruby on Rails 5.x - Do início ao fim!

Aqui ficará o conteúdo usado no curso.

![Capa do curso de Ruby on Rails 5.x](https://cdn-images-1.medium.com/max/1600/1*OZCuYAREKtSJHzfl4FYlvQ.jpeg)

Deseja adquirir o curso? Acesse o link abaixo e saiba como.

>> [Ruby on Rails - Do início ao fim!](https://www.udemy.com/course/rubyonrails-5x/?referralCode=5CDC4A6332959AB91860)
