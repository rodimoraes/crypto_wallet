class Subject < ApplicationRecord
  has_many :questions
end
