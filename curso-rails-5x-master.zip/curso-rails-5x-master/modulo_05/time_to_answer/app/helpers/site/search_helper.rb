module Site::SearchHelper
end
