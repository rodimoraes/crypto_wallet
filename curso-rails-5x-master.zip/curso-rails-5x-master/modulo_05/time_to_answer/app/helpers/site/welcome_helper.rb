module Site::WelcomeHelper
end
